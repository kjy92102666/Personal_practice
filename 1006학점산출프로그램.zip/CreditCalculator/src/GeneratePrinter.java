public class GeneratePrinter {

    //GoodSchool school = new GoodSchool();

    private void makeHeader(){

    }

    private void makeBody(Subject subject){

        //return subject;
    }

    private void makeFooter(){

    }

    public void showInfo(){

    }

    public void getScoreGrade(Student student, int subjectId){

    }
}
