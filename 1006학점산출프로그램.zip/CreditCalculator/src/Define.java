public class Define {
    public int KOREAN=0;
    public int MATH=0;
    public int AB_TYPE;
    public int SAB_TYPE;

}
