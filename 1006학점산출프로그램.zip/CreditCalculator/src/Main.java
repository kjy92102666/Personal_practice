import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("---------------------------------------------------");
        System.out.println("| name |\tid\t|\tmajor\t|korean score|math score|");

//        while(true){
//
//        }
    }
}