import java.util.ArrayList;
import java.util.List;

public class Student{
    private int studentId;
    private List<Score> scoreArr = new ArrayList<>();
    private Subject major;
    private String studentName;


    public Student(int studentId, String studentName, Subject major){
        this.studentId = studentId;
        this.studentName = studentName;
        this.major = major;
    }

    public void addSubjectScore(Score score){

    }

    public int getStudentId(int studentId){

        return 0;
    }

    public Subject getMajorSubject(){

        return null;
    }
}
