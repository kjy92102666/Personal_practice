public class SABEval implements BasicEval{

    @Override
    public String getGrade(int score) {

        return null;
    }
}
