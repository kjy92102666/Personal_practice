import java.util.ArrayList;
import java.util.List;

public class Subject {
    private List<Student> scoreArr = new ArrayList<>();
    private int id;
    private String name;
    private int gradeType;

    public Subject(String name, int id){
        this.name = name;
        this.id = id;
    }

    public void register(Student student){

    }

    public int getGradeType() { return gradeType; }
    public void setGradeType(int gradeType) { this.gradeType = gradeType; }

    public List<Student> getStudentList(){

        return null;
    }

    @Override
    public String toString() {
        return "Subject{" +
                "id=" + id +
                ", name='" + name + '\'' +
                '}';
    }
}
