import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.List;

public class GoodSchool {
    private List<Student> studentArr  = new ArrayList<>();
    private List<Subject> subjectArr= new ArrayList<>();
    private static GoodSchool instance = new GoodSchool();

    private GoodSchool(){
    }

    //이거 접.제 바꿔야되는거 아닌감.
    public static GoodSchool getInstance(){
        if(instance == null){
            instance = new GoodSchool();
        }
        return instance;
    }

    public void addStudent(){
//        Subject subject = new Subject("kim" , 2);
//        subject.getGradeType();
//        subject.getStudentList();

        studentArr.add(new Student(211213 ,"kim",new Subject("mat",2)));
        studentArr.add(new Student(212330,"park",new Subject("kor",1)));
        studentArr.add(new Student(201518 ,"lee",new Subject("kor",1)));
        studentArr.add(new Student(202360 ,"noa",new Subject("kor",1)));
        studentArr.add(new Student(201290 ,"you",new Subject("mat",2)));

    }

    public void addSubject(Subject subject){
        subjectArr.add(new Subject("mat",2));
        subjectArr.add(new Subject("kor",1));
        subjectArr.add(new Subject("kor",1));
        subjectArr.add(new Subject("kor",1));
        subjectArr.add(new Subject("mat",2));
        //System.out.println(subjectArr);
    }

    public List<Subject> getSubjectList(){
        subjectArr.add(new Subject("mat",2));
        subjectArr.add(new Subject("kor",1));
        subjectArr.add(new Subject("kor",1));
        subjectArr.add(new Subject("kor",1));
        subjectArr.add(new Subject("mat",2));

        return subjectArr;
    }

}
