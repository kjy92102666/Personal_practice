public class ABEval implements BasicEval{

    @Override
    public String getGrade(int score){

        return null;
    }
}
