public interface BasicEval {
    String getGrade(int score);
}
