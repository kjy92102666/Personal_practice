import java.sql.SQLOutput;

public class WebView {
    //GoodSchool school = new GoodSchool();

    public void crateStudent(Student student){

    }

    public void createSubject(Subject subject){

    }

    public void createScoreForStudent(Student student, Subject subject, int point){

    }

    public static void main(String[] args){
        GoodSchool gs = GoodSchool.getInstance();
        gs.addStudent();
        gs.addSubject(new Subject("kim12112", 2));

        gs.getSubjectList().stream().forEach(s->System.out.println(s.toString()));
        System.out.println();
        gs.getSubjectList().stream().forEach(s->System.out.println(s.toString()));


    }

}
